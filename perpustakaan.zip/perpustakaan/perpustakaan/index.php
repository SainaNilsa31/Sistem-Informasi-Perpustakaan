<?php
include 'koneksi.php';
?>

<!DOCTYPE html>
<html>
<head>
	<title>SIPERPUS</title>
	<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body background="C:\xampp\htdocs\perpustakaan\perpustakaan\user\public\img\perpus.jpeg">
	<div class="kotak_login">
		<p class="tulisan_login">Login</p>

		<form action="aksi_login.php" method="post">
			<label>Nama</label>
			<input type="text" name="nama" class="form_login" placeholder="Nama">

			<label>Password</label>
			<input type="password" name="password" class="form_login" placeholder="Password">

			<input type="submit" class="tombol_login" name="login" value="LOGIN">
			<br/>
			<br/>
			<center>
				Belum Punya Akun?
				<a class="link" href="daftar.php"> Registrasi</a>
			</center>
		</form>
		
	</div>
</body>
</html>
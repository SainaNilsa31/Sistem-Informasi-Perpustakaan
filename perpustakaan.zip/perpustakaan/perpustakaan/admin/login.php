<?php
include 'koneksi.php';
?>
<!DOCTYPE html>
<html>
<head>
	<title>SIPERPUS</title>
	<link rel="stylesheet" type="text/css" href="../style.css">
</head>
<body background="C:\xampp\htdocs\perpustakaan\perpustakaan\admin\public\img\perpus.jpeg">
	<div class="kotak_login">
		<p class="tulisan_login">LOGIN ADMIN</p>

		<form action="aksi_login.php" method="post">
			<label>Nama</label>
			<input type="text" name="nama" class="form_login" placeholder="Nama">

			<label>Password</label>
			<input type="password" name="password" class="form_login" placeholder="Password">

			<input type="submit" class="tombol_login" name="login" value="LOGIN">
			<br/>
			<br/>
		</form>
		
	</div>
</body>
</html>
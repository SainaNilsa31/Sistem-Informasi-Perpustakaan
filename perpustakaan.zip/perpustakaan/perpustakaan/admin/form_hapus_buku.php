<?php
include 'koneksi.php';

//menangkap data id yg dikirim dari URL
$id = $_GET['id_buku'];

//menghapus dari database
mysqli_query($koneksi,"DELETE FROM tb_buku WHERE id_buku='$id'");

//mengalihkan kembali ke halaman index
header("location:perpus.php");
?>
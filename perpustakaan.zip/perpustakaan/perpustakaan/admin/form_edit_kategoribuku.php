<?php 
  include 'koneksi.php';
  $id = $_GET['id_kategori'];
  $data= mysqli_query($koneksi,"SELECT * FROM tb_kategoribuku WHERE id_kategori='$id'");
  while($d=mysqli_fetch_array($data)){

 ?>
<html>
<head>
	<title>SIPERPUS</title>
	<link rel="stylesheet" type="text/css" href="css/style.css">
</head>
<body>

	<div class="kotak_login">
		<p class="tulisan_login">INPUT KATEGORI BUKU</p>

		<form action="aksi_edit_kategoribuku.php" method="post">

      <label>ID</label>
      <input type="text" name="id_kategori" class="form_login" value="<?php echo $d['id_kategori']?>" required>

		<label>Nama Kategori</label>
		<input type="text" name="kategori_buku" class="form_login" value="<?php echo $d['kategori_buku']?>" required>


      <input type="submit" class="tombol_login" name="edit" value="EDIT">
    </form>
    <?php
        }
        ?>
		
	</div>
</body>
</html>
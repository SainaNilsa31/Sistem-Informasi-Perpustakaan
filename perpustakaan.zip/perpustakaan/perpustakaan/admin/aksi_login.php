<?php
include 'koneksi.php';
session_start();
    include 'koneksi.php';

    //jika tombol login ditekan
    if (isset ($_POST["login"])) 
    {
        $nama = $_POST["nama"];
        $password= $_POST["password"];

        //lakukan query untuk ngecheck akun yang ada di tabel pelanggan yang berada di database
        $ambil = $koneksi->query("SELECT * FROM admin WHERE nama = '$nama'");

        //ngitung akun yang terambil
        $akunyangcocok = $ambil->num_rows;

        //jika 1 akun yang cocok,maka diloginkan
        if ($akunyangcocok==1) 
        {
            password_verify($password, $akunyangcocok['password']);
            //anda sukses login
            //mendapatan akun dalam bentuk array
            $akun = $ambil->fetch_assoc();
            
            //simpan di session admin
            if ($akun['hak']=="admin") {
            $_SESSION['admin'] = $nama;
            $_SESSION['hak'] = "admin";
            $_SESSION['login'] = true;
            echo "<script>alert('ANDA LOGIN SEBAGAI ADMIN');</script>";
            echo "<script>location='index.php';</script>";

            // //simpan di session user
            // if ($akun['status']=="1") {
            // $_SESSION['anggota_pengurus'] = $nim;
            // $_SESSION['hak'] = "user";
            // $_SESSION['login'] = true;
            // echo "<script>alert('ANDA LOGIN SEBAGAI USER');</script>";
            // echo "<script>location='user/index_user.php';</script>";
            // }
        }
    }
}
            //anda gagal login
            echo "<script>alert('FAILED LOGIN');</script>";
            echo "<script>location='login.php';</script>";
     ?>
<?php
  include 'koneksi.php';
if (isset($_POST["edit"]))
  {
$id            	= $_POST["id_buku"];
$judul       	= $_POST["judul"];
$pengarang 	 	= $_POST["pengarang"];
$penerbit  		= $_POST["penerbit"];
$tahun_terbit  	= $_POST["tahun_terbit"];
$isbn          	= $_POST["isbn"];
$jumlah_buku  	= $_POST["jumlah_buku"];
$kategori_buku   = $_POST["kategori_buku"];

$aksi = mysqli_query($koneksi,"UPDATE tb_buku SET id_buku='$id',judul='$judul',pengarang='$pengarang',penerbit='$penerbit'
,tahun_terbit='$tahun_terbit',isbn='$isbn',jumlah_buku='$jumlah_buku',kategori_buku='$kategori_buku' WHERE id_buku='$id'");

	echo "<script>alert('BERHASIL');</script>";
	echo "<script>location='perpus.php';</script>";
}
?>
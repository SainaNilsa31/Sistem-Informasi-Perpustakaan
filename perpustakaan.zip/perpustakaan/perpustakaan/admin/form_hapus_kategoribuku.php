<?php
include 'koneksi.php';

//menangkap data id yg dikirim dari URL
$id = $_GET['id_kategori'];

//menghapus dari database
mysqli_query($koneksi,"DELETE FROM tb_kategoribuku WHERE id_kategori='$id'");

//mengalihkan kembali ke halaman index
header("location:kategori.php");
?>
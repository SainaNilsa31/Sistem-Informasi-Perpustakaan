<?php 
  include 'koneksi.php';
 ?>
<html>
<head>
	<title>SIPERPUS</title>
	<link rel="stylesheet" type="text/css" href="../style.css">
</head>
<body>

	<div class="kotak_login">
		<p class="tulisan_login">FORM EDIT</p>
    <?php 
    include 'koneksi.php';
    $no_ktp = $_GET['no_ktp'];
    $data= mysqli_query($koneksi,"SELECT * FROM anggota WHERE no_ktp='$no_ktp'");
    while($d=mysqli_fetch_array($data)){
    ?>  
		<form action="aksi_edit_anggota.php" method="post">

			<label>NO KTP</label>
      <input type="text" name="no_ktp" class="form_login" value="<?php echo $d['no_ktp']?>" readonly>
      <br>

			<label>Nama</label>
			<input type="text" name="nama" class="form_login" value="<?php echo $d['nama']?>" required>


			<label>Jenis Kelamin</label>
			<select name="jenis_kelamin" class="form_login" required>
          		<option value="L" <?php if($d['jenis_kelamin'] == 'L'){ echo 'selected';}?>>Laki-Laki</option>
              <option value="P" <?php if($d['jenis_kelamin'] == 'P'){ echo 'selected';}?>>Perempuan</option>
			</select>

			<label>Alamat</label>
			<input type="text" name="alamat" class="form_login" value="<?php echo $d['alamat']?>" required>

			<label>No hp</label>
			<input type="text" name="no_hp" class="form_login" value="<?php echo $d['no_hp']?>" required>

			<label>Email</label>
			<input type="text" name="email" class="form_login" value="<?php echo $d['email']?>" required>

			<label>Password</label>
			<input type="password" name="password" class="form_login" minlength="6" maxlength="15" required>

			<label>Konfirmasi Password</label>
			<input type="password" name="password2" class="form_login" minlength="6" maxlength="15" required>

			<input type="submit" class="tombol_login" name="edit" value="EDIT">
			<br/>
			<br/>
		</form>
		<?php
        }
        ?>
	</div>
</body>
</html>
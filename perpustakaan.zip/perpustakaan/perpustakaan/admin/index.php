<?php
session_start();
include 'koneksi.php';
include 'function.php';

if (!isset($_SESSION['login'])) {
  header("location:login.php");
  exit;
}
?>
<html>
  <head>
    <link href="public/css/style.css" rel="stylesheet" />
    <link href="https://fonts.googleapis.com/css?family=Slabo+27px" rel="stylesheet">
  </head>
  <body background="public/img/pattern.jpg">
    <header>
      <link href="public/css/style.css" rel="stylesheet" type="text/css">
      <nav>
        <ul>
          <a class="menu" href="index.php">Anggota</a>
          <a class="menu" href="calon.php">Pendaftar</a>
          <a class="menu" href="perpus.php">Daftar Buku</a>
          <a class="menu" href="kategori.php">Daftar Kategori Buku</a>
          <a class="menu" href="transaksi.php">Daftar Transaksi</a>
          <a class="menu" href="logout.php">Logout</a>
        </ul>
      </nav>
    </header>
    <br><br><br>
    <section>
      <div id="article-list">
        <h1>DATA ANGGOTA</h1>
        <table>
    <td width="10%">
    <a href="daftar.php"><input type="submit" class="tombol_login" name="input" value="Tambah Data"></a>
    <a href="laporan_anggota_excel.php"><input type="submit" class="tombol_login" name="input" value="Export To Excel"></a></td>
  </table>

  <table width="1" border="1" cellpadding="5" cellspacing="0">
       <tr>
        <thead>
                  <tr>
                    <th>No</th>
                    <th>No KTP</th>
                    <th>Nama</th>
                    <th>Jenis Kelamin</th>
                    <th>Email</th>
                    <th>No HP</th>
                    <th>Alamat</th>
                    
                    <th>Aksi</th>
                  </tr>
        </thead>
        <tbody>
                   <?php 
                    include 'koneksi.php';
                    $no = 1;
                    $data = mysqli_query($koneksi, "SELECT * FROM anggota WHERE status='1'");
                    while ($d = mysqli_fetch_array($data)) {?>
                      <tr>
                      <td><?php echo $no++?></td>
                      <td><?php echo $d['no_ktp']?></td>
                      <td><?php echo $d['nama']?></td>
                      <td><?php echo $d['jenis_kelamin']?></td>
                      <td><?php echo $d['email']?></td>
                      <td><?php echo $d['no_hp']?></td>
                      <td><?php echo $d['alamat']?></td>
                      
                      <td>
                      <a href="form_edit_anggota.php?no_ktp=<?php echo $d['no_ktp'];?>">EDIT</a>
                      <a href="form_hapus_anggota.php?no_ktp=<?php echo $d['no_ktp'];?>" onclick="return confirm('YAKIN INGIN MENGHAPUS DATA?');">HAPUS</a>
                      </td>
                    </tr>
                    <?php 
                  } 
                
                    ?>



                </tbody>
      </tr>
    </table>
      </div>
    </section>
  </body>
</html>
<?php 
include 'koneksi.php';

$id = $_GET['id_buku'];
$judul = $_GET['judul'];
$nama = $_GET['nama'];

$sql = $koneksi->query("UPDATE tb_transaksi SET status='kembali' WHERE nama='$nama' AND nama='$nama'");

$sql = $koneksi->query("UPDATE tb_buku SET jumlah_buku = (jumlah_buku+1) WHERE judul ='$judul'");

echo "<script>alert('Kembali Buku Berhasil');</script>";
          echo "<script>location='transaksi.php';</script>";
 ?>
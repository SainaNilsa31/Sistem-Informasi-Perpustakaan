<?php
include 'koneksi.php';

//menangkap data id yg dikirim dari URL
$no_ktp = $_GET['no_ktp'];

//menghapus dari database
mysqli_query($koneksi,"DELETE FROM anggota WHERE no_ktp='$no_ktp'");

//mengalihkan kembali ke halaman index
header("location:index.php");
?>
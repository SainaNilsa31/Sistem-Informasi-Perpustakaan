<?php
include 'koneksi.php';
  if (isset($_POST["tambah"]))
  {   
$id              = $_POST["id_buku"];
$judul           = $_POST["judul"];
$pengarang       = $_POST["pengarang"];
$penerbit        = $_POST["penerbit"];
$tahun_terbit    = $_POST["tahun_terbit"];
$isbn            = $_POST["isbn"];
$jumlah_buku     = $_POST["jumlah_buku"];
$kategori_buku   = $_POST["kategori_buku"];

//cek apakah id sudah digunakan
                                $ambil = $koneksi->query("SELECT * FROM tb_buku WHERE id_buku='$id'");
                                    $yangcocok = $ambil->num_rows;
                                    if ($yangcocok==1){
                                        echo "<script>alert('Penambahan gagal, id buku sudah digunakan');</script>";
                                        echo "<script>location='form_tambah_buku.php';</script>";
                                    }
//menginput data ke database
$koneksi->query("INSERT INTO tb_buku
  (id_buku,judul,pengarang,penerbit,tahun_terbit,isbn,jumlah_buku,kategori_buku)
    VALUES('$id','$judul','$pengarang','$penerbit','$tahun_terbit','$isbn','$jumlah_buku','$kategori_buku')");
echo "<script>alert('Penambahan buku sukses');</script>";
echo "<script>location='perpus.php';</script>"; 
}
?>
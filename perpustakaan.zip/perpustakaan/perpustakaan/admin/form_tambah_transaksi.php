<?php
session_start();
include 'koneksi.php';
include 'function.php';

$tgl_pinjam = date("d-m-Y");
$tujuh_hari = mktime(0,0,0, date("n"),date("j")+14, date("Y"));
$kembali = date("d-m-Y", $tujuh_hari);

if (!isset($_SESSION['login'])) {
  header("location:login.php");
  exit;
}
?>
<html>
<head>
	<title>SIPERPUS</title>
	<link rel="stylesheet" type="text/css" href="css/style.css">
</head>
<body>

	<div class="kotak_login">
		<p class="tulisan_login">INPUT TRANSAKSI</p>

		<form method="post" onsubmit="return validasi(this)">
    <label>ID Transaksi</label>
      <input type="text" name="id_transaksi" class="form_login" required>

      <label>Nama Buku</label>
      <select name="buku" class="form_login" required>
      <?php 
       
        include 'koneksi.php';
        $data= mysqli_query($koneksi,"SELECT * FROM tb_buku");
        while($d=mysqli_fetch_array($data)){
         
        ?>  
            	<option value="<?= $d['judul']?>"><?= $d["judul"]?></option>
              <?php
        }
        ?>
			</select>
      <label>Nama Peminjam</label>
    <select name="nama" class="form_login" required>
      <?php 
        include 'koneksi.php';
        $data= mysqli_query($koneksi,"SELECT * FROM anggota");
        while($d=mysqli_fetch_array($data)){
        ?>  
            	<option value="<?= $d['nama']?>"><?= $d["nama"]?></option>
              <?php
        }
        ?>
      <label>Tanggal Pinjam</label>
			<input type="date" name="tgl_pinjam" id="tgl" value="<?php echo $tgl_pinjam;?>" class="form_login">

      <label>Tanggal Kembali</label>
      <input type="date" name="tgl_kembali" id="tgl" value="<?php echo $kembali;?>" class="form_login">
      <input type="submit" class="tombol_login" name="simpan" value="simpan">
    </form>
	</div>
</body>
</html>

<?php 
  if (isset($_POST['simpan'])) {


    $tgl_pinjam = $_POST['tgl_pinjam'];
    $tgl_kembali = $_POST['tgl_kembali'];

    $judul = $_POST['buku'];
    $nama = $_POST['nama'];
    $id_transaksi = $_POST['id_transaksi'];

    $sql = $koneksi->query("SELECT * FROM tb_buku WHERE judul = '$judul'");
    while ($data = $sql->fetch_assoc()) {
      $sisa = $data['jumlah_buku'];

      if ($sisa == 0) {
          echo "<script>alert('Stok Buku Sudah Habis');</script>";
          echo "<script>location='form_tambah_transaksi.php';</script>";
      }else{
        $sql = $koneksi->query("INSERT INTO tb_transaksi(id_transaksi,judul,nama, tgl_pinjam,tgl_kembali,status)VALUES('$id_transaksi','$judul','$nama','$tgl_pinjam','$tgl_kembali','pinjam')");
        $sql2 = $koneksi->query("UPDATE tb_buku SET jumlah_buku=(jumlah_buku-1) WHERE id_buku='$id'");

        echo "<script>alert('Simpan Data Berhasil');</script>";
        echo "<script>location='transaksi.php';</script>";
      }
    }
  }
?>

<?php 
  include 'koneksi.php';
 ?>
<html>
<head>
	<title>SIPERPUS</title>
	<link rel="stylesheet" type="text/css" href="../style.css">
</head>
<body>

	<div class="kotak_login">
		<p class="tulisan_login">FORM EDIT BUKU</p>
    <?php 
    include 'koneksi.php';
    $id = $_GET['id_buku'];
    $data= mysqli_query($koneksi,"SELECT * FROM tb_buku WHERE id_buku='$id'");
    while($d=mysqli_fetch_array($data)){
    ?>  
		<form action="aksi_edit_buku.php" method="post">

			<label>ID</label>
      <input type="text" name="id_buku" class="form_login" value="<?php echo $d['id_buku']?>" readonly>
      <br>

			<label>Judul</label>
			<input type="text" name="judul" class="form_login" value="<?php echo $d['judul']?>" required>

      <label>Pengarang</label>
      <input type="text" name="pengarang" class="form_login" value="<?php echo $d['pengarang']?>" required>

      <label>Penerbit</label>
      <input type="text" name="penerbit" class="form_login" value="<?php echo $d['penerbit']?>" required>

      <label>Tahun Terbit</label>
      <input type="text" name="tahun_terbit" class="form_login" value="<?php echo $d['tahun_terbit']?>" required>

      <label>ISBN</label>
      <input type="text" name="isbn" class="form_login" value="<?php echo $d['isbn']?>" required>

      <label>Jumlah Buku</label>
      <input type="text" name="jumlah_buku" class="form_login" value="<?php echo $d['jumlah_buku']?>" required>


			<label>Kategori Buku</label>
			<select name="kategori_buku" class="form_login" required>
      <?php 
        include 'koneksi.php';
        $data= mysqli_query($koneksi,"SELECT * FROM tb_kategoribuku");
        while($d=mysqli_fetch_array($data)){
        ?>  
            	<option value="<?= $d['id_kategori']?>"><?= $d["kategori_buku"]?></option>
              <?php
        }
        ?>
			</select>

			<input type="submit" class="tombol_login" name="edit" value="EDIT">
			<br/>
			<br/>
		</form>
		<?php
        }
        ?>
	</div>
</body>
</html>
<?php
session_start();
include 'koneksi.php';
include 'function.php';

if (!isset($_SESSION['login'])) {
  header("location:login.php");
  exit;
}
?>
<html>
  <head>
    <link href="public/css/style.css" rel="stylesheet" />
    <link href="https://fonts.googleapis.com/css?family=Slabo+27px" rel="stylesheet">
  </head>
  <body background="public/img/perpus.jpeg">
    <header>
      <link href="public/css/style.css" rel="stylesheet" type="text/css">
      
      <nav>
        <ul>
          <a class="menu" href="index.php">Anggota</a>
          <a class="menu" href="calon.php">Pendaftar</a>
          <a class="menu" href="perpus.php">Daftar Buku</a>
          <a class="menu" href="kategori.php">Daftar Kategori Buku</a>
          <a class="menu" href="transaksi.php">Daftar Transaksi</a>
          <a class="menu" href="logout.php">Logout</a>
        </ul>
      </nav>
    </header>
    <br><br><br>
    <section>
      <div id="article-list">
        <h1>DATA BUKU</h1>
        <table>
    <td width="10%"><a href="form_tambah_buku.php"><input type="submit" class="tombol_login" name="input" value="Tambah Buku"></a>
    <a href="laporan_buku_excel.php"><input type="submit" class="tombol_login" name="input" value="Export To Excel"></a></td>
  </table>
  
  <table width="1" border="1" cellpadding="5" cellspacing="0">

       <tr>
        <thead>
                  <tr>
                    <th>No</th>
                    <th>ID</th>
                    <th>Judul</th>
                    <th>Pengarang</th>
                    <th>Penerbit</th>
                    <th>Tahun Terbit</th>
                    <th>ISBN</th>
                    <th>Jumlah Buku</th>
                    <th>Kategori Buku</th>
                    <th>Aksi</th>
                  </tr>
        </thead>
        <tbody>
                   <?php 
                    include 'koneksi.php';
                    $no = 1;
                    $data = mysqli_query($koneksi, "SELECT * FROM tb_buku");
                    while ($d = mysqli_fetch_array($data)) {?>
                      <tr>
                      <td><?php echo $no++?></td>
                      <td><?php echo $d['id_buku']?></td>
                      <td><?php echo $d['judul']?></td>
                      <td><?php echo $d['pengarang']?></td>
                      <td><?php echo $d['penerbit']?></td>
                      <td><?php echo $d['tahun_terbit']?></td>
                      <td><?php echo $d['isbn']?></td>
                      <td><?php echo $d['jumlah_buku']?></td>
                      <td><?php echo $d['kategori_buku']?></td>
                      <td>
                      <a href="form_edit_buku.php?id_buku=<?php echo $d['id_buku'];?>">EDIT</a>
                      <a href="form_hapus_buku.php?id_buku=<?php echo $d['id_buku'];?>" onclick="return confirm('YAKIN INGIN MENGHAPUS DATA?');">HAPUS</a>
                      </td>
                    </tr>
                    <?php 
                  } 
                    ?>
                </tbody>
      </tr>
    </table>
      </div>
    </section>
  </body>
</html>
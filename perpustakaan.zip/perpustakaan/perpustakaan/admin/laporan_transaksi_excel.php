<?php 
include 'koneksi.php';

$filename = "transaksi_excel-(".date('d-m-y').").xls";

header("content-disposition: attachment; filename=$filename");
header("content-type: application/vdn.ms-excel");
?>

<h2>Laporan Buku</h2>

<table border="1">
	<tr>
        <thead>
                  <tr>
                    <th>No</th>
                    <th>ID</th>
                    <th>Judul</th>
                    <th>NIM</th>
                    <th>Nama</th>
                    <th>Tanggal Pinjam</th>
                    <th>Tanggal Kembali</th>
                    
                    <th>Status</th>
                    
                  </tr>
        </thead>
        <tbody>
        <?php 
                    include 'koneksi.php';
                    $no = 1;
                    $data = mysqli_query($koneksi, "SELECT * FROM tb_transaksi");
                    while ($d = mysqli_fetch_array($data)) {?>
                    	<tr>
                      <td><?php echo $no++?></td>
                      <td><?php echo $d['id']?></td>
                      <td><?php echo $d['judul']?></td>
                      <td><?php echo $d['nim']?></td>
                      <td><?php echo $d['nama']?></td>
                      <td><?php echo $d['tgl_pinjam']?></td>
                      <td><?php echo $d['tgl_kembali']?></td>
                      <td><?php echo $d['status']?></td>
                  
                  </tr>
                  <?php 
                  } 
                
                    ?>
                    </tbody>
      </tr>
</table>
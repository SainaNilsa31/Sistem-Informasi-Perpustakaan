<?php
include 'koneksi.php';
  if (isset($_POST["daftar"]))
  {
$no_ktp         = $_POST["no_ktp"];
$nama           = $_POST["nama"];
$jenis_kelamin  = $_POST["jenis_kelamin"];
$email          = $_POST["email"];
$no_hp          = $_POST["no_hp"];
$alamat         = $_POST["alamat"];
$password       = $_POST["password"];
$password2      = $_POST["password2"];
$status         = '0';

//cek apakah email sudah digunakan
                                $ambil = $koneksi->query("SELECT * FROM anggota WHERE no_ktp='$no_ktp'");
                                    $yangcocok = $ambil->num_rows;
                                    if ($yangcocok==1){
                                        echo "<script>alert('Penambahan gagal, No KTP sudah digunakan');</script>";
                                        echo "<script>location='daftar.php';</script>";
                                    }elseif ($password == $password2) {

//enkripsi password
  $password = password_hash($password, PASSWORD_DEFAULT);

//menginput data ke database
$koneksi->query("INSERT INTO anggota (no_ktp,nama,jenis_kelamin,email,no_hp,alamat,password,status)VALUES('$no_ktp','$nama','$jenis_kelamin','$email','$no_hp','$alamat','$password','$status')");
echo "<script>alert('Penambahan sukses, silahkan tunggu di approve');</script>";
echo "<script>location='calon.php';</script>"; 
}else{
    echo "<script>alert('password tidak sesuai');</script>";
    echo "<script>location='daftar.php';</script>";
}
}
?>
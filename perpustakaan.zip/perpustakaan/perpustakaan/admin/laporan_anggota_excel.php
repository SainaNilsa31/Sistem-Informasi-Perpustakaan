<?php 
include 'koneksi.php';

$filename = "anggota_excel-(".date('d-m-y').").xls";

header("content-disposition: attachment; filename=$filename");
header("content-type: application/vdn.ms-excel");
?>

<h2>Laporan Anggota</h2>

<table border="1">
	<tr>
        <thead>
                  <tr>
                    <th>No</th>
                    <th>NIM</th>
                    <th>Nama</th>
                    <th>Jenis Kelamin</th>
                    <th>Tanggal Lahir</th>
                    <th>Email</th>
                    <th>No HP</th>
                    <th>Alamat</th>
                    <th>Jurusan</th>
                    <th>Prodi</th>
                    <th>Bidang</th>
                    <th>Jabatan</th>
                  </tr>
        </thead>
        <tbody>
        <?php 
                    include 'koneksi.php';
                    $no = 1;
                    $data = mysqli_query($koneksi, "SELECT * FROM anggota WHERE status='1'");
                    while ($d = mysqli_fetch_array($data)) {?>
                    	<tr>
                      <td><?php echo $no++?></td>
                      <td><?php echo $d['nim']?></td>
                      <td><?php echo $d['nama']?></td>
                      <td><?php echo $d['jenis_kelamin']?></td>
                      <td><?php echo $d['tanggal_lahir']?></td>
                      <td><?php echo $d['email']?></td>
                      <td><?php echo $d['no_hp']?></td>
                      <td><?php echo $d['alamat']?></td>
                      <td><?php echo $d['id_jurusan']?></td>
                      <td><?php echo $d['id_prodi']?></td>
                      <td><?php echo $d['id_bidang']?></td>
                      <td><?php echo $d['id_jabatan']?></td>
                  </tr>
                  <?php 
                  } 
                
                    ?>
                    </tbody>
      </tr>
</table>
<?php 
include 'koneksi.php';

$filename = "buku_excel-(".date('d-m-y').").xls";

header("content-disposition: attachment; filename=$filename");
header("content-type: application/vdn.ms-excel");
?>

<h2>Laporan Buku</h2>

<table border="1">
	<tr>
        <thead>
                  <tr>
                    <th>No</th>
                    <th>ID</th>
                    <th>Judul</th>
                    <th>Pengarang</th>
                    <th>Penerbit</th>
                    <th>Tahun Terbit</th>
                    <th>ISBN</th>
                    <th>Jumlah Buku</th>
                    <th>Lokasi</th>
                    <th>Tanggal Input</th>
                    
                  </tr>
        </thead>
        <tbody>
        <?php 
                    include 'koneksi.php';
                    $no = 1;
                    $data = mysqli_query($koneksi, "SELECT * FROM tb_buku");
                    while ($d = mysqli_fetch_array($data)) {?>
                    	<tr>
                      <td><?php echo $no++?></td>
                      <td><?php echo $d['id']?></td>
                      <td><?php echo $d['judul']?></td>
                      <td><?php echo $d['pengarang']?></td>
                      <td><?php echo $d['penerbit']?></td>
                      <td><?php echo $d['tahun_terbit']?></td>
                      <td><?php echo $d['isbn']?></td>
                      <td><?php echo $d['jumlah_buku']?></td>
                      <td><?php echo $d['lokasi']?></td>
                      <td><?php echo $d['tgl_input']?></td>
                  
                  </tr>
                  <?php 
                  } 
                
                    ?>
                    </tbody>
      </tr>
</table>
<?php
session_start();
include 'koneksi.php';
include 'function.php';

if (!isset($_SESSION['login'])) {
  header("location:login.php");
  exit;
}
?>
<html>
  <head>
    <link href="public/css/style.css" rel="stylesheet" />
    <link href="https://fonts.googleapis.com/css?family=Slabo+27px" rel="stylesheet">
  </head>
  <body background="public/img/pattern.jpg">
    <header>
      <link href="public/css/style.css" rel="stylesheet" type="text/css">
      
      <nav>
        <ul>
          <a class="menu" href="index.php">Anggota</a>
          <a class="menu" href="calon.php">Pendaftar</a>
          <a class="menu" href="perpus.php">Daftar Buku</a>
          <a class="menu" href="kategori.php">Daftar Kategori Buku</a>
          <a class="menu" href="transaksi.php">Daftar Transaksi</a>
          <a class="menu" href="logout.php">Logout</a>
        </ul>
      </nav>
    </header>
    <br><br><br>
    <section>
      <div id="article-list">
        <h1>DATA TRANSAKSI</h1>
        <table>
    <td width="10%"><a href="form_tambah_transaksi.php"><input type="submit" class="tombol_login" name="input" value="Tambah Data"></a>
      <a href="laporan_transaksi_excel.php"><input type="submit" class="tombol_login" name="input" value="Export To Excel"></a></td></td>
  </table>
  
  <table width="1" border="1" cellpadding="5" cellspacing="0">

       <tr>
        <thead>
                  <tr>
                    <th>No</th>
                    <th>ID</th>
                    <th>Judul</th>
                    <th>Nama</th>
                    <th>Tanggal Pinjam</th>
                    <th>Tanggal Kembali</th>
                    <th>Terlambat</th>
                    <th>Status</th>
                    <th>Aksi</th>
                  </tr>
        </thead>
        <tbody>
                   <?php 
                    include 'koneksi.php';
                    $no = 1;
                    $data = mysqli_query($koneksi, "SELECT * FROM tb_transaksi WHERE status='pinjam'");
                    while ($d = mysqli_fetch_array($data)) {?>
                      <tr>
                      <td><?php echo $no++?></td>
                      <td><?php echo $d['id_transaksi']?></td>
                      <td><?php echo $d['judul']?></td>
                      <td><?php echo $d['nama']?></td>
                      <td><?php echo $d['tgl_pinjam']?></td>
                      <td><?php echo $d['tgl_kembali']?></td>
                      <td>
                        <?php 
                        $denda = 1000;

                        $tgl_dateline2 = $d["tgl_kembali"];
                        $tgl_kembali = date("Y-m-d");

                        $lambat = terlambat($tgl_dateline2, $tgl_kembali);
                        $denda = $lambat*$denda;

                        if ($lambat>0) {
                          echo "<font color='red'>$lambat hari<br>(Rp $denda)</font>";
                        }else{
                          echo $lambat." "."Hari";
                        }

                         ?>

                      </td>
                      <td><?php echo $d['status']?></td>
                      
                      <td>
                      <a href="kembali_buku.php?id_transaksi=<?php echo $d['id_transaksi'];?>&judul=<?php echo $d['judul'];?>&nama=<?php echo $d['nama'];?>">Kembali</a>
                      <a href="perpanjang_buku.php?id_transaksi=<?php echo $d['id_transaksi'];?>&nama=<?php echo $d['nama'];?>&judul=<?php echo $d['judul'];?>&lambat=<?php echo $lambat;?>&tgl_kembali=<?php echo $d['tgl_kembali'];?>" onclick="return confirm('PERPANJANG MASA PINJAMAN?');">Perpanjang</a>
                      </td>
                    </tr>
                    <?php 
                  } 
                
                    ?>



                </tbody>
      </tr>
    </table>
      </div>
    </section>
  </body>
</html>
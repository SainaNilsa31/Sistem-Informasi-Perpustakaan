<?php 
  include 'koneksi.php';
 ?>
<html>
<head>
	<title>SIPERPUS</title>
	<link rel="stylesheet" type="text/css" href="css/style.css">
</head>
<body>

	<h1><img src="img/download.jpg" height="100" width="100"></h1>

	<div class="kotak_login">
		<p class="tulisan_login">INPUT KATEGORI BUKU</p>

		<form action="aksi_kategori_buku.php" method="post">

      <label>ID</label>
      <input type="text" name="id_kategori" class="form_login" required>

		<label>Nama Kategori</label>
		<input type="text" name="kategori_buku" class="form_login" required>


      <input type="submit" class="tombol_login" name="tambah" value="TAMBAH">
    </form>
		
	</div>
</body>
</html>
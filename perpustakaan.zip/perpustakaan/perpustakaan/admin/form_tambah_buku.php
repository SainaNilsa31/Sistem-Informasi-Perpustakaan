
 <?php 
  include 'koneksi.php';
 
 ?>
<html>
<head>
	<title>SIPERPUS</title>
	<link rel="stylesheet" type="text/css" href="css/style.css">
</head>
<body>

	<div class="kotak_login">
		<p class="tulisan_login">INPUT BUKU</p>

		<form action="aksi_tambah_buku.php" method="post">

			<label>Judul</label>
			<input type="text" name="judul" class="form_login" required>

      <label>Pengarang</label>
      <input type="text" name="pengarang" class="form_login" required>

      <label>Penerbit</label>
      <input type="text" name="penerbit" class="form_login" required>

      <label>Tahun Terbit</label>
      <input type="text" name="tahun_terbit" class="form_login" required>

      <label>ISBN</label>
      <input type="text" name="isbn" class="form_login" required>

      <label>Jumlah Buku</label>
      <input type="text" name="jumlah_buku" class="form_login" required>

			<label>Kategori Buku</label>
      <select name="buku" class="form_login" required>
      <?php 
       
        include 'koneksi.php';
        $data= mysqli_query($koneksi,"SELECT * FROM tb_kategoribuku");
        while($d=mysqli_fetch_array($data)){
         
        ?>  
            	<option value="<?= $d['id_kategori']?>"><?= $d["kategori_buku"]?></option>
              <?php
        }
        ?>
			</select>

      <input type="submit" class="tombol_login" name="tambah" value="TAMBAH">
      </form>
		
	</div>
</body>
</html>
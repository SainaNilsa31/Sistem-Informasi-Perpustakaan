<?php
include 'koneksi.php';
  if (isset($_POST["tambah"]))
  {   
$id              = $_POST["id_kategori"];
$kategori_buku   = $_POST["kategori_buku"];

//cek apakah id sudah digunakan
                                $ambil = $koneksi->query("SELECT * FROM tb_kategoribuku WHERE id_kategori='$id'");
                                    $yangcocok = $ambil->num_rows;
                                    if ($yangcocok==1){
                                        echo "<script>alert('Penambahan gagal, id buku sudah digunakan');</script>";
                                        echo "<script>location='form_kategori_buku.php';</script>";
                                    }
//menginput data ke database
$koneksi->query("INSERT INTO tb_kategoribuku
  (id_kategori,kategori_buku)
    VALUES('$id','$kategori_buku')");
echo "<script>alert('Penambahan Kategori Buku Sukses');</script>";
echo "<script>location='kategori.php';</script>"; 
}
?>
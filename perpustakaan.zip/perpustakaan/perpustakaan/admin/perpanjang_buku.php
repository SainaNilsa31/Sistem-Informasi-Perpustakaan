<?php 
include 'koneksi.php';

$id = $_GET['id_transaksi'];
$judul = $_GET['judul'];
$tgl_kembali = $_GET['tgl_kembali'];
$lambat = $_GET['lambat'];

if ($lambat > 7) {
	echo "<script>alert('Tidak dapat di perpanjang, karena lebih dari 7 hari');</script>";
          echo "<script>location='transaksi.php';</script>";
}else{
	$pecah_tgl_kembali = explode("-", $tgl_kembali);
	$next_7_hari = mktime(0,0,0, $pecah_tgl_kembali[1], $pecah_tgl_kembali[0]+14, $pecah_tgl_kembali[2]);
	$hari_next = date("d-m-y", $next_7_hari);

	$sql = $koneksi->query("UPDATE tb_transaksi SET tgl_kembali='$hari_next' WHERE id_transaksi='$id' AND nama='$nama'");

	if ($sql) {
		echo "<script>alert('Perpanjangan Berhasil');</script>";
          echo "<script>location='transaksi.php';</script>";
	}else{
		echo "<script>alert('Perpanjangan Gagal');</script>";
          echo "<script>location='transaksi.php';</script>";
	}
}
 ?>	
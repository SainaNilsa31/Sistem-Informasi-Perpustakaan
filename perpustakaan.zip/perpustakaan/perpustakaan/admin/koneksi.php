<?php 
	$host		= 'localhost';
	$username	= 'root';
	$pass		= '';
	$database	= 'perpustakaan';
	$koneksi	= mysqli_connect($host, $username, $pass, $database);
 ?>
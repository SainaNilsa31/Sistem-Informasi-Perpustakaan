<?php
  include 'koneksi.php';
if (isset($_POST["edit"]))
  {
$id            	= $_POST["id_kategori"];
$kategori_buku   = $_POST["kategori_buku"];


$aksi = mysqli_query($koneksi,"UPDATE tb_kategoribuku SET id_kategori='$id',kategori_buku='$kategori_buku' WHERE id_kategori='$id'");

	echo "<script>alert('BERHASIL');</script>";
	echo "<script>location='kategori.php';</script>";
}
?>
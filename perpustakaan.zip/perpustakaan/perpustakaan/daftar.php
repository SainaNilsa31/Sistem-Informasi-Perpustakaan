<?php 
  include 'koneksi.php';
 ?>
<html>
<head>
	<title>SIPERPUS</title>
	<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>

	<h1><img src="img/1.png" height="100" width="100"></h1>

	<div class="kotak_login">
		<p class="tulisan_login">Silahkan Daftar</p>

		<form action="aksi_daftar.php" method="post">

			<label>Nama</label>
			<input type="text" name="nama" class="form_login" required>


			<label>Jenis Kelamin</label>
			<select name="jenis_kelamin" class="form_login" required>
          		<option value="L">Laki-Laki</option>
            	<option value="P">Perempuan</option>
			</select>

      <label>Email</label>
			<input type="text" name="email" class="form_login" placeholder="email" required>

      <label>No KTP</label>
			<input type="text" name="no_ktp" class="form_login" required>

      <label>No hp</label>
			<input type="text" name="no_hp" class="form_login" required>

			<label>Alamat</label>
			<input type="text" name="alamat" class="form_login" required>
      </select>

			<label>Password</label>
			<input type="password" name="password" class="form_login" minlength="6" maxlength="15" required>

			<label>Konfirmasi Password</label>
			<input type="password" name="password2" class="form_login" minlength="6" maxlength="15" required>

			<input type="submit" class="tombol_login" name="daftar" value="DAFTAR">
			<br/>
			<br/>
			<center>
				Sudah Punya Akun?
				<a class="link" href="index.php"> Login</a>
			</center>
		</form>
		
	</div>
</body>
</html>
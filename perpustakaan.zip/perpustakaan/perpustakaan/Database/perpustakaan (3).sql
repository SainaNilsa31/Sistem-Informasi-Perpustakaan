-- phpMyAdmin SQL Dump
-- version 4.9.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 18 Jan 2020 pada 06.07
-- Versi server: 10.4.10-MariaDB
-- Versi PHP: 7.3.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `perpustakaan`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `admin`
--

CREATE TABLE `admin` (
  `nim` varchar(10) NOT NULL,
  `nama` varchar(200) NOT NULL,
  `password` varchar(15) NOT NULL,
  `hak` varchar(7) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data untuk tabel `admin`
--

INSERT INTO `admin` (`nim`, `nama`, `password`, `hak`) VALUES
('1857301033', 'Iqbal', '123123', 'admin');

-- --------------------------------------------------------

--
-- Struktur dari tabel `anggota`
--

CREATE TABLE `anggota` (
  `nim` varchar(10) NOT NULL,
  `nama` varchar(200) NOT NULL,
  `jenis_kelamin` enum('L','P') NOT NULL,
  `tanggal_lahir` date NOT NULL,
  `alamat` varchar(200) NOT NULL,
  `no_hp` varchar(15) NOT NULL,
  `email` varchar(200) NOT NULL,
  `id_jurusan` varchar(10) NOT NULL,
  `id_prodi` varchar(10) NOT NULL,
  `id_jabatan` varchar(10) NOT NULL,
  `id_bidang` varchar(10) NOT NULL,
  `password` varchar(15) NOT NULL,
  `status` int(1) NOT NULL,
  `hak` varchar(5) NOT NULL,
  `date_created` date NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data untuk tabel `anggota`
--

INSERT INTO `anggota` (`nim`, `nama`, `jenis_kelamin`, `tanggal_lahir`, `alamat`, `no_hp`, `email`, `id_jurusan`, `id_prodi`, `id_jabatan`, `id_bidang`, `password`, `status`, `hak`, `date_created`) VALUES
('1857301002', 'Rahma', 'P', '2000-05-05', 'cunda', '085362920643', 'qwe@gmail.com', 'TM', 'TM-TM', 'KABID', 'KADER', '$2y$10$ys/DrHIi', 1, 'user', '2020-01-15'),
('1857301009', 'Nabila', 'P', '2000-01-12', 'cunda', '085362920643', 'qwe@gmail.com', 'TM', 'TM-TM', 'AG', 'KADER', '$2y$10$W68zz6dt', 0, '', '2020-01-15'),
('1857301010', 'Saifannur', 'L', '2000-07-08', 'cunda', '0852698744', 'iki@gmail.com', 'TM', 'TM-TM', 'AG', 'KADER', '$2y$10$7vG0m6v4', 0, '', '2020-01-15'),
('1857301011', 'Muhammad Riza', 'L', '2000-05-05', 'cunda', '085362920643', 'qwe@gmail.com', 'TK', 'TK-TRKI', 'AG', 'MEDIS', '$2y$10$3.ILloT7', 0, '', '2020-01-15'),
('1857301020', 'Afrizal', 'L', '2000-05-15', 'cunda', '085362920343', 'adsw@gmail.com', 'TM', 'TM-TM', 'AG', 'MEDIS', '$2y$10$5nsXVkGE', 0, '', '2020-01-15'),
('1857301041', 'Zulfahmi', 'L', '2000-02-12', 'mns.mesjid cunda', '085362920343', 'julkifli.muhammad@yahoo.com', 'TM', 'TM-TRM', 'KABID', 'KADER', '123123', 1, 'user', '2019-12-26'),
('1857301045', 'Catur Bima', 'L', '2000-04-05', 'Lhokseumawe', '085362920643', 'adsw@gmail.com', 'TN', 'TN-AK', 'KABID', 'BPM', '123123', 1, 'user', '2019-12-26'),
('1857301099', 'Ahmad Kurniawan', 'L', '1999-05-02', 'cunda', '085248693311', 'qwe@gmail.com', 'TE', 'TE-TE', 'KABID', 'MEDIS', '$2y$10$AXZtW4el', 1, 'user', '2020-01-18');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tb_buku`
--

CREATE TABLE `tb_buku` (
  `id` varchar(10) NOT NULL,
  `judul` varchar(200) NOT NULL,
  `pengarang` varchar(100) NOT NULL,
  `penerbit` varchar(150) NOT NULL,
  `tahun_terbit` varchar(4) NOT NULL,
  `isbn` varchar(25) NOT NULL,
  `jumlah_buku` varchar(3) NOT NULL,
  `lokasi` enum('rak1','rak2','rak3') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data untuk tabel `tb_buku`
--

INSERT INTO `tb_buku` (`id`, `judul`, `pengarang`, `penerbit`, `tahun_terbit`, `isbn`, `jumlah_buku`, `lokasi`) VALUES
('123', 'Bahasa Indonesia', 'Sarbani', 'Grandmedia', '2015', '12356', '10', 'rak1'),
('1665', 'Popi', 'Sarbani', 'Grandmedia', '2015', '12356', '3', 'rak2'),
('ABD15', '97 Masalah Populer', 'Abdul Somad', 'Grandmedia', '2015', '97dsr17', '12', 'rak2'),
('Cplus15', 'Bahasa Program C++', 'Sarbani', 'Grandmedia', '2015', '12356', '3', 'rak2'),
('IKI2', 'IT', 'Sarbani', 'Grandmedia', '2015', '12356', '9', 'rak2'),
('MTD17', 'Matematika Dasar', 'Kindi', 'Grandmedia', '2017', '17mtkdsr', '9', 'rak1'),
('MTK13', 'Matematika', 'Ahmad', 'Grand Media', '2013', '13mtk20', '4', 'rak1'),
('PHP18', 'Bahasa PHP', 'Khalid', 'Grand Media', '2018', '18php20', '8', 'rak3'),
('UJI15', 'Roti Bakar', 'Sarbani', 'Grandmedia', '2015', '12356', '3', 'rak2');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tb_transaksi`
--

CREATE TABLE `tb_transaksi` (
  `id` varchar(10) NOT NULL,
  `judul` varchar(200) NOT NULL,
  `nim` varchar(15) NOT NULL,
  `nama` varchar(200) NOT NULL,
  `tgl_pinjam` varchar(30) NOT NULL,
  `tgl_kembali` varchar(30) NOT NULL,
  `status` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data untuk tabel `tb_transaksi`
--

INSERT INTO `tb_transaksi` (`id`, `judul`, `nim`, `nama`, `tgl_pinjam`, `tgl_kembali`, `status`) VALUES
('ABD15', '97 Masalah Populer', '1857301010', 'Saifannur', '15-01-2020', '12-02-20', 'pinjam'),
('123', 'Bahasa Indonesia', '1857301009', 'Nabila', '15-01-2020', '29-01-2020', 'pinjam'),
('123', 'Bahasa Indonesia', '1857301041', 'Zulfahmi', '16-01-2020', '30-01-2020', 'pinjam'),
('123', 'Bahasa Indonesia', '1857301006', 'Muhammad Iqbal', '17-01-2020', '31-01-2020', 'pinjam'),
('ABD15', '97 Masalah Populer', '1857301002', 'Rahma', '17-01-2020', '31-01-2020', 'pinjam'),
('IKI2', 'IT', '1857301002', 'Rahma', '17-01-2020', '31-01-2020', 'pinjam'),
('UJI15', 'Roti Bakar', '1857301002', 'Rahma', '18-01-2020', '08-02-20', 'kembali');

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`nim`);

--
-- Indeks untuk tabel `anggota`
--
ALTER TABLE `anggota`
  ADD PRIMARY KEY (`nim`);

--
-- Indeks untuk tabel `tb_buku`
--
ALTER TABLE `tb_buku`
  ADD PRIMARY KEY (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
